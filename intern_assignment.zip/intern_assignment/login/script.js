const toggleForm = () => {
    const container = document.querySelector('.container');
    container.classList.toggle('active');
  };